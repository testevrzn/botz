const gbin = () => { 
	return `       
*BINS:* 

*VRAU DOMINA* 🐊🚩
000-000-00`

}
exports.gbin = gbin
