const gpessoa = (prefix) => {

return `*GERADORE DE DADOS PESSOAIS:*

*VRAU DOMINA* 🐊🚩

`
}
exports.gpessoa = gpessoa
